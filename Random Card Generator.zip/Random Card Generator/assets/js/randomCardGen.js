let cards = [1,2,3,4,5,6,7,8,9,10,11,12,13];
let suits = [1,2,3,4];
let clickCounter = 0;



//When Draw a Card is clicked
$("button").click(function(){
    resetCard();
    cardGenerator();
    suitGenerator();
    $(".cardContainerInner").css({
        "background-color": "white",
        "background-image": "none"
    });
    clickCounter++;

});


function suitGenerator(){
    //Select a random number between 1-4
    let randomSuit = suits[Math.floor(Math.random() * suits.length)];
    //Number 1 represents a heart, Number 2 a diamond, Number 3 a Club, and 4 a spade
    //If suit is 1 or 2 - set color of card and suit icon to red
    if(randomSuit === 1){
        $("#heart").addClass("show");
        $("h2").addClass("red");
    }
    else if(randomSuit === 2){
        $("#diamond").addClass("show");
        $("h2").addClass("red");
    }
    //Else leave color black
    else if(randomSuit === 3){
        $("#club").addClass("show");
        $("h2").addClass("black");
    }
    else{
        $("#spade").addClass("show");
        $("h2").addClass("black");
    }
}

function cardGenerator(){
    //Select a random number between 1-13
    let randomCard = cards[Math.floor(Math.random() * cards.length)];
    //Number 1 is an Ace and should be represented accordingly
    if(randomCard === 1){
        $("h2").text("A");
    }
    //Numbers 11-13 represent face cards and should be changed accordingly
    else if(randomCard === 11){
        $("h2").text("J");
    }
    else if(randomCard === 12){
        $("h2").text("Q");
    }
    else if(randomCard === 13){
        $("h2").text("K");
    }
    else{
        $("h2").text(randomCard);
    }
}

function resetCard(){
    $("img").removeClass("show");
    $("h2").removeClass("red black");
}

    //Display selected card number and suit in an overlay in the center of the screen
    //Create new button below the card
        //Allows user to draw a new card