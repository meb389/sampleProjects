var h1 = document.getElementById("mainHeading");
var winnerHeader = document.getElementById("winnerHeader");

var letsPlay = document.getElementById("letsPlay");
var reset = document.getElementById("reset");
var newGame = document.getElementById("newGame");

var playerOneScoreTally = 1;
var playerTwoScoreTally = 1;
var moves = 0;
var playerTracker = true;

var playerOneScore = document.getElementById("p1Score");
var playerTwoScore = document.getElementById("p2Score");

var header = document.getElementById("heading");
var square = document.querySelectorAll(".box");

var game = document.getElementById("gameBoard");
var startScreen = document.getElementById("startScreen");
var winnerPopUp = document.getElementById("winnerScreen");
var body = document.querySelector("body");

//______________________________________________________________________________________________________________________
//Creating the functionality for both the rest button and the new match button

//Creating the let's play button and the reset button
//The let's play button activates the game board and hides the initial popup screen
letsPlay.addEventListener("click", function(){
    startScreen.classList.add("hide");
    header.classList.remove("hide");
    reset.classList.remove("hide");
    game.classList.remove("hide");
});

reset.addEventListener("click", function(){
    restart();
});

//Main functionality of the game, runs through toggling between players and checks to see if there is a winner
for(var i = 0; i < square.length; i++){
    boardFunction();
    gameMode();
}

//______________________________________________________________________________________________________________________

//Toggles between each player & checks to see if the clicked square is available or not
function boardFunction(){
    square[i].addEventListener("click", function(){
        //For player one, change square blue
        if(this.classList.contains("blue") || this.classList.contains("green")){
            alert("This square is taken");
        }
        else if(playerTracker === true){
            this.classList.add("blue");
            h1.textContent = "Player Two's Turn";
            playerTracker = false;
        }
        //For player two, change square green
        else if (playerTracker === false) {
        this.classList.add("green");
        h1.textContent = "Player One's Turn";
         playerTracker = true;
        }
        moves++;
    });
}

//Check all possible winning combinations to see if either player has one
function gameMode(){
    square[i].addEventListener("click", function(){
        if(square[0].classList.contains("blue") && square[1].classList.contains("blue") && square[2].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[3].classList.contains("blue") && square[4].classList.contains("blue") && square[5].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[6].classList.contains("blue") && square[7].classList.contains("blue") && square[8].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[0].classList.contains("blue") && square[3].classList.contains("blue") && square[6].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[1].classList.contains("blue") && square[4].classList.contains("blue") && square[7].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[2].classList.contains("blue") && square[5].classList.contains("blue") && square[8].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[0].classList.contains("blue") && square[4].classList.contains("blue") && square[8].classList.contains("blue") && moves < 9){
            playerOneWinner();
        } else if(square[2].classList.contains("blue") && square[4].classList.contains("blue") && square[6].classList.contains("blue") && moves < 9){
            playerOneWinner();
        }

        else if(square[0].classList.contains("green") && square[1].classList.contains("green") && square[2].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[3].classList.contains("green") && square[4].classList.contains("green") && square[5].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[6].classList.contains("green") && square[7].classList.contains("green") && square[8].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[0].classList.contains("green") && square[3].classList.contains("green") && square[6].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[1].classList.contains("green") && square[4].classList.contains("green") && square[7].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[2].classList.contains("green") && square[5].classList.contains("green") && square[8].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[0].classList.contains("green") && square[4].classList.contains("green") && square[8].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(square[2].classList.contains("green") && square[4].classList.contains("green") && square[6].classList.contains("green") && moves < 9){
            playerTwoWinner();
        } else if(moves === 8){
            header.style.backgroundColor = "red";
            h1.textContent = "It's A Tie, Try Again!";
        }
    });
}

//If player one has a winning combination
function playerOneWinner(){
    playerOneScore.textContent = playerOneScoreTally;
    playerOneScoreTally++;
    winnerPopScreen();
}

//If player two has a winning combination
function playerTwoWinner(){
    playerTwoScore.textContent = playerTwoScoreTally;
    playerTwoScoreTally++;
    winnerPopScreen();
}

function winnerPopScreen(){
    if(playerTracker === false){
        winnerHeader.textContent = "Player One Wins!";
        body.classList.add("blue");
    } else{
        winnerHeader.textContent = "Player Two Wins!";
        body.classList.add("green");
    }
    winnerPopUp.classList.remove("hide");
    header.classList.add("hide");
    reset.classList.add("hide");
    game.classList.add("hide");
    newGame.addEventListener("click", function(){
        restart();
        winnerPopUp.classList.add("hide");
        body.classList.remove("blue");
        body.classList.remove("green");
    });
}

//Reset the game when the reset button is pressed
function restart(){
    h1.textContent = "Player One's Turn";
    for(var i = 0; i < square.length; i++){
        square[i].classList.remove("blue");
        square[i].classList.remove("green");
        moves = 0;
        header.style.backgroundColor = "steelblue";
        header.classList.remove("hide");
        reset.classList.remove("hide");
        game.classList.remove("hide");
    }
    playerTracker = true;
}

